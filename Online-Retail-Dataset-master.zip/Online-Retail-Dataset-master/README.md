# Online-Retail-Dataset
Solution for Online Retail Dataset

This notebook contains Python solution for the data set which contains transactions occurring between 01/12/2010 and 09/12/2011 for a UK-based and registered non-store online retail. The analysis includes data exploration, description of data quality problems occuring in dataset and application of RFM analysis.

Data Source: http://archive.ics.uci.edu/ml/datasets/Online+Retail
